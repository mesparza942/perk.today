<!DOCTYPE html>
<html>

@include('layout.head')

<body onload="loadScript()">

@include('layout.header')

@include($template)



</body>
</html>