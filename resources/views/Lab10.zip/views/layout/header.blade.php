<header>
	<div class="fullwidth">
		<div class="four left">
			<img class="logo" src="<?php echo url('/'); ?>/images/perkb-logo.png" alt="Perk logo header">
		</div>
		<div id="buscador" class="half left">
			<input id="adress" type="text"
			placeholder="Enter a location">
		</div>
		<div class="four left tright">
			<img src="<?php echo url('/'); ?>/images/marker-perk.png" alt="Marker" class="marker-header">
		</div>
		@include('layout.menu-principal')
	</div>
</header>