<head>
	<script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
	
	<!--<script type="text/javascript" src="<?php echo url('/'); ?>/js/jquery.js"></script>-->
	<link rel="stylesheet" type="text/css" href="<?php echo url('/'); ?>/css/main.css">
	<link rel="stylesheet" type="text/css" href="<?php echo url('/'); ?>/css/font-awesome.css">
	<meta name="viewport" content="initial-scale=1.0, user-scalable=no">
    <meta charset="utf-8">
	<!-- <link rel="stylesheet" type="text/css" href="<?php echo url('/'); ?>/css/slider.css"> -->
	<title>PERK</title>

</head>