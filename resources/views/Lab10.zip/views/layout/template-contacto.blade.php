<div class="content bgwhite">
	<div class="fullwidth center">
		<h1 class="blue">Contáctanos</h1>
	</div>
	<div class="left fullwidth bggrey">
		<div class="wrapper">
			<div style="margin: 10px 0px;">
				<div class="sixty left">
					<div class="d3">
						<div class="wrapper">
							<img class="fullwidth" src="<?php echo url('/'); ?>/images/contact.png">
						</div>
						<div class="wrapper">
						<p class="justify parrafo">
							Tienes dudas de cómo funciona y cómo vas a ganar dinero con nuestro programa "Renta tu parqueadero"? </p>
						<p>	No te preocupes, aclaramos todas las dudas que tengas, solo déjanos tus datos y en la brevedad posible nos pondremos en contacto contigo. </p>
						
						</div>
					</div>
				</div>
				@include('layout.formulario-contacto')
			</div>
		</div>
	</div>
</div>